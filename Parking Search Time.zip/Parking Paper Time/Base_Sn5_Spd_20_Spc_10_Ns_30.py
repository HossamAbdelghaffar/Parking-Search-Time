# -*- coding: utf-8 -*-
"""

"""

import os
import numpy as np
import win32com.client as com
import pandas as pd
import matplotlib.pyplot as plt
import operator
import math
import csv
from datetime import datetime
import statistics
from time import sleep
import sys
from scipy.stats import multivariate_normal
from mpl_toolkits.mplot3d import Axes3D
import random

#Clearing the Screen
print("\033[H\033[J")

def gen_veh_dataframe():
    global veh_data
    veh_data = pd.read_csv('{}.fzp'.format(output_file), skiprows=19, sep=r'\s*;\s*', header= 0, engine = 'python')
    veh_data = veh_data.rename(columns={'$VEHICLE:SIMSEC':'SIMSEC'})
    
def gen_dcp_dataframe():
    global data
    data = pd.read_csv('{}.mer'.format(output_file), skiprows=249, sep=r'\s*;\s*', header= 0, engine = 'python')
    for m in range(1, 241):  #Hoss Total detectors number =240 skiprows=249 not 129
        data.loc[data['Measurem.'] == m, 'Spot'] = math.ceil(m/2) 
    

def timesteps(sim, dt):
    x = 180 + (sim*dt)
    y = 180 + ((sim+1)*dt)
    return [x, y]                   # start and end of time interval


def get_timestep_data(time_int):
    global data
    con1 = data['t(Entry)']>= time_int[0]
    con2 = data['t(Entry)']<= time_int[1]
    return data[con1 & con2]

def remove_conflict(curr_df):
    return curr_df[~curr_df.duplicated(['Spot'], keep = 'first')]

        
def get_excel_file():
    global probability_data
    probability_df = pd.DataFrame.from_dict(probability_data)
    probability_df.to_excel("probability data.xlsx",sheet_name='Sheet_name_1')

def parking_found(rn, available_parkings):
    dfPark = pd.DataFrame(columns=['Measurem.', 't(Entry)', 't(Exit)', 'VehNo', 'Vehicle type', 'Line', 'v[km/h]', 'b[m/s2]', 'Occ', 'Pers', 'tQueue', 'VehLength[m]'])
    for spot in available_parkings:
        x = rn[rn['Spot'] == spot]
        dfPark = dfPark.append(x, sort = False)
    dfPark.sort_values(by=['t(Entry)'])
    return dfPark[~dfPark.duplicated(['VehNo'], keep = 'first')]    

def update_times(curr_timesteps, parked_time, searched_time, parked_loc, parked_distance, searched_distance):
    global veh_data
    time_rn = np.around(curr_timesteps[1], decimals=1)
    for veh in parked_loc['VehNo']:
        if parked_time[veh]==0:
            parked_time[veh] = time_rn
            
            call = veh_data[veh_data["SIMSEC"]==time_rn]
            parked_distance[veh] = call[call["NO"]==veh]["DISTTRAVTOT"].iloc[0]
        else:
            time_found = np.around(parked_loc[parked_loc['VehNo'] == veh]['t(Entry)'].iloc[0], decimals=1)
            searched_time[veh].append(time_found - parked_time[veh])
            parked_time[veh] = time_rn
            
            call_1 = veh_data[veh_data["SIMSEC"]==time_found]
            searched_distance[veh].append(call_1[call_1["NO"]==veh]["DISTTRAVTOT"].iloc[0]- parked_distance[veh])
            call = veh_data[veh_data["SIMSEC"]==time_rn]
            parked_distance[veh] = call[call["NO"]==veh]["DISTTRAVTOT"].iloc[0]
            
    return parked_time, searched_time, parked_distance, searched_distance

def get_average_search_time(N_s,searched_time):
    avgs = 0
    for cars in range(N_s):
        avgs += sum(searched_time[cars+1])/len(searched_time[cars+1])
    return avgs/N_s

def get_average_search_distance(N_s, searched_distance):
    avgs = 0
    for cars in range(N_s):
        avgs += sum(searched_distance[cars+1])/len(searched_distance[cars+1])
    return avgs/N_s

def initialize_dict(N_s):    
    p_d = {}
    p_t = {}
    s_t = {}
    s_d = {}
    for i in range(N_s):
        p_d[i+1]=0
        p_t[i+1]=0
        s_t[i+1]=[]
        s_d[i+1]=[]
    return p_t, s_t, p_d, s_d
            
    
os.chdir(r'C:\Users\ADDPATHHERE')
cwd = os.getcwd()
Vissim = com.Dispatch("Vissim.Vissim")
file_name = 'Sn5_Spd_20_Spc_10_Ns_30'  + '.inpx'
instance_file_location = os.path.join(cwd, file_name)
Vissim.LoadNet(instance_file_location)
layout_file_location = os.path.join(cwd, file_name[:-4]+str('layx'))
Vissim.LoadLayout(layout_file_location)
Vissim.Graphics.CurrentNetworkWindow.SetAttValue("QuickMode",1)
#Vissim.SuspendUpdateGUI()

output_file = file_name[:-5] + '_001'    

Vissim.Simulation.SetAttValue('RandSeed', 976)
#Vissim.Simulation.RunContinuous()

average_30cars = {"distance":[],"time":[]}

for occ in [30]:
    park_list = list(range(1,121))   #Hoss Total available parking lots =120
    occupancy = occ#%
    speed_kmh = 20
    N_s=30
    probability_data = {'Time': [], 'Probability': [], 'vdt':list(range(50, 1201, 50)) } 
    parked_time, searched_time, parked_distance, searched_distance = initialize_dict(N_s)
    
    dfObj = pd.DataFrame(columns=['Measurem.', 't(Entry)', 't(Exit)', 'VehNo', 'Vehicle type', 'Line', 'v[km/h]', 'b[m/s2]', 'Occ', 'Pers', 'tQueue', 'VehLength[m]'])
    gen_veh_dataframe()
    gen_dcp_dataframe()
    
    dt = 10
    Probaility_parkingFound_TimeInterval = []
    
    for sim in range(1000):
        available_parkings = random.sample(park_list, (math.floor(len(park_list)*(100-occupancy)/100)))
        curr_timesteps = timesteps(sim, dt)
        curr_df = get_timestep_data(curr_timesteps)
        rn = remove_conflict(curr_df)
        parked_loc = parking_found(rn, available_parkings)
        parked_time, searched_time, parked_distance, searched_distance = update_times(curr_timesteps, parked_time, searched_time, parked_loc, parked_distance, searched_distance)
        Probaility_parkingFound_TimeInterval.append((len(parked_loc)/N_s))
            
        
    AvgProbaility_parkingFound_Allintervals = sum(Probaility_parkingFound_TimeInterval)/(sim+1)  
    average_30cars["time"].append(get_average_search_time( N_s, searched_time))
    average_30cars["distance"].append(get_average_search_distance( N_s, searched_distance))
    
    
