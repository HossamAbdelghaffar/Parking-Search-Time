# -*- coding: utf-8 -*-
""" """

import math

#Clearing the Screen
print("\033[H\033[J") 

q=0.90                     # Occupancy                                        --- Bio & CaM Model
Ns=30                      # Number of Serchers                               --- CaM Model
dspots=20                  # space between parking Spots (m)                  --- Bio Model
Vcruise=30                 # Averge Simulated Cruise for parking speed (km/h) --- Bio & CaM Model
#-----------------------
Deltat=10                   # Time interval (s)                                --- CaM Model
L=1200                      # Total N/W Length (m)                             --- CaM Model
A=L/dspots                  # Total parcking Capacity, including occupied      --- CaM Model
Vcruise=Vcruise*1000/3600   # Cruise for parking speed (m/s)                   --- Bio & CaM Model
d=Deltat* Vcruise           # Traveled distance during deltat with speed Vcruise (m)  --- CaM Model 

print("\n**Input**")
print("Number of Searchers=", format(Ns, '.2f')) 
print("Occupancy=", format(q, '.2f')) 
print("----------------") 


#-------------(Start) ----- binomial approximation -------------Bio Model------
# Equations (1,2)
print("\n**Bionomial Model**")
print("Equation (2)")
     
Parking_Search_Time_Bio=dspots/(Vcruise*(1-q))                  # Seconds
print("Parking Probability_Bio=", format((1-q), '.2f'))
print("Parking Search Time_Bio=", format(Parking_Search_Time_Bio, '.2f'), "sec") 
print("----------------") 
 
#-------------(End) ------- binomial approximation -------------Bio Model------   

#-------------(Start) ----- Cao and Menendez (2015b) ---------- CaM Model------
# Equation (4a)
print("\n**Cao and Menendez Model**")

if q<=(1-(Ns/A)):    
    
   if Deltat >=0 and Deltat <= (L/(Vcruise*Ns)):
       print("Equation (4a-1)")
       Prob=1-(1-(Vcruise*Deltat/L))**(A*(1-q))      # the average probability of finding parking
       print("Probability_CaM=", format(Prob, '.2f'))
       
   if Deltat > (L/(Vcruise*Ns)) and Deltat < (L/Vcruise):
       print("Equation (4a-2)")
       Prob=1+((1-(1/Ns))**(A*(1-q)))*(math.log((Vcruise*Deltat/L),Ns))
       print("Probability_CaM=", format(Prob, '.2f'))
       
   if Deltat >= (L/Vcruise) and Deltat < math.inf:
       print("Equation (4a-3)")
       Prob=1
       print("Probability_CaM=", format(Prob, '.2f'))
#------------------------------------------------------------------------------
# Equation (4b)

if q>=(1-(Ns/A)):    
    
   if Deltat >=0 and Deltat <= (L/(Vcruise*Ns)):
       print("Equation (4b-1)")
       Prob=1-(1-(Vcruise*Deltat/L))**(A*(1-q))
       print("Probability_CaM=", format(Prob, '.2f'))
       
   if Deltat > (L/(Vcruise*Ns)) and Deltat < ((L*A*(1-q))/(Vcruise*Ns)):
       print("Equation (4b-2)")
       Prob=(A*(1-q)/Ns)+((A*(1-q)/Ns)-1+(1-(1/Ns))**(A*(1-q)))*(math.log((Vcruise*Deltat*Ns/(A*(1-q)*L)),((A*(1-q)))))
       print("Probability_CaM=", format(Prob, '.2f'))
       
   if Deltat >= ((L*A*(1-q))/(Vcruise*Ns)) and Deltat < math.inf:
       print("Equation (4b-3)")
       Prob=(A*(1-q))/Ns
       print("Probability_CaM=", format(Prob, '.2f'))
#------------------------------------------------------------------------------
# Equation (5)
       
Parking_Search_Time_CaM=Deltat/Prob                             # Seconds
print("Parking Search Time_CaM=", format(Parking_Search_Time_CaM, '.2f'), "sec")


#-------------(End) ------- Cao and Menendez (2015b) ---------- CaM Model------

